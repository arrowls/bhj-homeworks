const words = [
    'Bob',
    'Я люблю JS',
    'Нетология',
    'FrontEnd',
    'awesome',
    'netology',
    'hello',
    'kitty',
    'rock',
    'youtube',
    'popcorn',
    'cinema',
    'love',
    'javascript',
];
const wordContainer = document.querySelector('.word');
const timer = document.querySelector('.timer');
const background = document.querySelector('div.card');
let currentLetterElement;
const CHANGE_WORD_TIMING = 100;
const SECONDS_PER_LETTER = 1;
const failCounter = document.querySelector('.status__loss');
const successCounter = document.querySelector('.status__wins');
let interval;


function awaitSpaceInput(evt) {
  if (evt.key == ' ') {
    document.querySelector('.popup-visible').classList.remove('popup-visible');
    renderWord();
    failCounter.textContent = 0;
    successCounter.textContent = 0;
    window.removeEventListener('keyup', awaitSpaceInput)
  }
}
function clear() {
    wordContainer.innerHTML = '';
    window.removeEventListener('keyup', onKeyPress);
    clearInterval(interval);
    timer.style.width = '0%';
}
function fail() {
  failCounter.textContent++;
  if (failCounter.textContent == 3) {
    clear();
    showPopup('fail');
    window.addEventListener('keyup', awaitSpaceInput)
    return;
  }
  background.classList.add('word_incorrect')
  setTimeout(() => background.classList.remove('word_incorrect'), 200)
  setTimeout(() => renderWord(), CHANGE_WORD_TIMING);
}
function success() {
  successCounter.textContent++;
  if (successCounter.textContent == 3) {
    clear();
    showPopup('success');
    window.addEventListener('keyup', awaitSpaceInput);
    return;
  }
  renderWord();
}
function showPopup(type) {
  document.querySelector(`.popup_${type}`).classList.add('popup-visible');
}
function getRandomWord() {
    return words[Math.floor(Math.random() * words.length)];
}
function getCurrentLetter() {
    return wordContainer.querySelector('.symbol_active').textContent;
}
function initTimer(count) {
  clearInterval(interval);
  const seconds = count * SECONDS_PER_LETTER;
  let width = 100;
  interval = setInterval(() => {
    timer.style.width = `${width - (100 / (seconds / 0.05))}%`;
    timer.style.backgroundColor = `hsl(${width}, 100%, 50%)`;
    width -= (100 / (seconds / 0.05));
    if (width <= 0) {
      fail();
      clearInterval(interval);
    }
  }, 50)
}
function isModifierPressed(evt) {
    return (
        evt.key == 'Control' ||
        evt.key == 'Meta' ||
        evt.key == 'Alt' ||
        evt.key == 'Shift' ||
        evt.key == 'Backspace' ||
        evt.key == 'Tab' ||
        evt.key == 'Enter' ||
        evt.key == 'CapsLock'
    );
}
function nextLetter() {
    currentLetterElement.classList.remove('symbol_active');
    if (!currentLetterElement.nextElementSibling) {
        success();
        return;
    }
    currentLetterElement = currentLetterElement.nextElementSibling;
    currentLetterElement.classList.add('symbol_active');
    currentLetterElement.classList.add('game_test');
}
function renderWord() {
    clear();
    [...getRandomWord()].forEach((letter, index) => {
        wordContainer.insertAdjacentHTML(
            'beforeend',
            `<span class="symbol${
                index == 0 ? ' symbol_active' : ''
            }">${letter}</span>`
        );
        currentLetterElement = document.querySelector('.symbol_active');
    });
    initTimer(wordContainer.childElementCount);
    window.addEventListener('keyup', onKeyPress);
}
function onKeyPress(evt) {
    if (isModifierPressed(evt)) {
        return;
    }
    if (evt.key == getCurrentLetter()) {
        currentLetterElement.classList.add('symbol_correct');
        nextLetter();
    } else {
        fail();
    }
}
renderWord();
